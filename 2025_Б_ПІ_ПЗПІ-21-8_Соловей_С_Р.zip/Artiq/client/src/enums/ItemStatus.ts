export enum ItemStatus {
  ACTIVE = 'active',
  CREATED = 'created',
  SOLD = 'sold',
}