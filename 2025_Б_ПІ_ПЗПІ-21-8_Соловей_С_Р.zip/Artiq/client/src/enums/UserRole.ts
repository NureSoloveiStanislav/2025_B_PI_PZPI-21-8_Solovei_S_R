export enum UserRole {
  Admin = 'admin',
  Buyer = 'buyer',
  Seller = 'seller'
}